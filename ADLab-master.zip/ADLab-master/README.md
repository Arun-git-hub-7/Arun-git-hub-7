AD Penetration Testing Lab
                                                                             
Author: @browninfosecguy

Version: 1.0

Usage: This Script can be used to configure both Domain Controller and Workstation.

OPTIONS APPLICABLE TO SERVER:

Option 1: Configure machine name and static IP address for the Domain Controller.

Option 2: Install the "Active Directory Domain Services" role on the server and configure Domain Controller. 

Option 3: Set up network share on the Domain controller and Workstation.

Option 4: Create Group policy to "disable" Windows Defender.

Option 5: Create User accounts on the Domain Controller.

OPTIONS APPLICABLE TO WORKSTATION:

Option 3: Set up network share on the Domain controller and Workstation.

Option 6: Configure machine name and set the DNS to IP address of Domain Controller.

Option 7: Join the workstation to the Domain.